install.packages("readxl")
install.packages("dplyr")
install.packages("DDL")
library(readxl)
library(dplyr)
library(DDL)



file_path <- "C:\\Users\\hp\\Desktop\\new\\R.xlsx" 
data <- read_excel(file_path, sheet = 1)

#share ~power+power^2+control
 X <- as.matrix(data %>% select(-lndwl,-share ,-lnfixasset ,-size,-share2 ,-lnfixasset2 ,-size2)) 
 Y <- data$share
 set.seed(123)
 print(head(data))
 index <- c(1, 2)
 result <- DDL(X, Y, index)
 summary(result)

#size ~power+power^2+control
 set.seed(123)
 Y <- data$size
 index <- c(1, 2)
 result1 <- DDL(X, Y, index)
 summary(result1)

#fixedassets ~power+power^2+control
 set.seed(123)
 Y <- data$lnfixasset
 index <- c(1, 2)
 result2 <- DDL(X, Y, index)
 summary(result2)

 set.seed(123)
 Y <- data$lndwl
 X <- as.matrix(data %>% select(-lndwl,-lnfixasset ,-size, -lnfixasset2 ,-size2)) 
 index <- c(1, 2,3,4)
 result3 <- DDL(X, Y, index)
 summary(result3)

 set.seed(123)
 X <- as.matrix(data %>% select(-lndwl,-share, -lnfixasset, -share2 ,-lnfixasset2)) 
 index <- c(1, 2,3,4)
 result4 <- DDL(X, Y, index)
 summary(result4)
 


 set.seed(123)
 X <- as.matrix(data %>% select(-lndwl,-share ,-size, -share2 ,-size2)) 
 index <- c(1, 2,3,4)
 result5 <- DDL(X, Y, index)
 summary(result5)





